﻿# color theme folder

- see [Setup Files]/[theme file] in help
- Tera Term color theme plugin was referened.
  - https://osdn.net/users/doda/pf/TTXColorTheme/

## themes

- Solarized Dark
  - http://ethanschoonover.com/solarized
- Solarized Light
- Tronesque
  - https://github.com/aurelienbottazini/tronesque
- xterm
- PuTTY
- Tera Term Pro 2.3
- Draula
  - https://github.com/dracula/windows-terminal
- Windows XP Console
  - https://en.wikipedia.org/wiki/ANSI_escape_code#Colors
- Windows 10 Console
  - https://en.wikipedia.org/wiki/ANSI_escape_code#Colors
- Color UniversalDesign 4
  - 色覚多様性に対応した設定例
  - カラーユニバーサルデザイン(CUD)推奨配色セット ver.4に準拠
